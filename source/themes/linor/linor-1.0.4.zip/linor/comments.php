<section id="comments">
	<h2 class="title"><?php _e('Comments', 'linor') ?></h2>
	<?php if ( post_password_required() ) : // if post needs password ?>
	<p class="notification"><?php _e('This post is password protected. Enter the password to view any comments.', 'linor'); ?></p>
	<?php return; endif; // end if post needs password ?>
	<?php if (have_comments()) : // if have comments ?>
		<ol class="commentlist"><?php wp_list_comments(array('callback'=>'linor_comments')); ?></ol>
		<?php if (get_option('page_comments')) : // if comments pagination are opened
			$comment_pages = paginate_comments_links(array('prev_text' => '&lt;', 'next_text' => '&gt;','echo' => 0));
			if ($comment_pages) : // if comments pages larger than 1
		?>
			<div class="wp-pagenavi"><?php echo $comment_pages; ?></div>
		<?php endif; // end if comments pages larger than 1
		endif; // end if comments pagination are opened ?>
		<?php else : if (!comments_open()) : // if comments are closed ?>
			<p class="notification"><?php _e('Comments are closed.', 'linor'); ?></p>
		<?php endif; // end if comments are closed ?>
	<?php endif; // end if have comments ?>
	<?php
	$fields = array(
		'author' => '<p class="comment-form-author"><label for="author">'.__('Name', 'linor').'</label><input id="author" name="author" type="text" placeholder="'.__('Name', 'linor').'"></p>',
		'email' => '<p class="comment-form-email"><label for="email">'.__('Email', 'linor').'</label><input id="email" name="email" type="text" placeholder="'.__('Email', 'linor').'"></p>',
		'url' => '<p class="comment-form-url"><label for="url">'.__('Website', 'linor').'</label><input id="url" name="url" type="text"  placeholder="'.__('Website', 'linor').'"></p>'
	);
	$args = array(
		'fields' => apply_filters('comment_form_default_fields', $fields),
		'comment_field' => '<p class="comment-form-comment">'
		.'<a class="bold" href="javascript:void(0)" title="'.__('Bold', 'linor').'">'.__('Bold', 'linor').'</a>'
		.'<a class="italic" href="javascript:void(0)" title="'.__('Italic', 'linor').'">'.__('Italic', 'linor').'</a>'
		.'<a class="delete" href="javascript:void(0)" title="'.__('Delete', 'linor').'">'.__('Delete', 'linor').'</a>'
		.'<a class="link" href="javascript:void(0)" title="'.__('Link', 'linor').'">'.__('Link', 'linor').'</a>'
		.'<a class="quote" href="javascript:void(0)" title="'.__('Blockquote', 'linor').'">'.__('Blockquote', 'linor').'</a>'
		.'<a class="image" href="javascript:void(0)" title="'.__('Image', 'linor').'">'.__('Image', 'linor').'</a>'
		.'<a class="code" href="javascript:void(0)" title="'.__('Code', 'linor').'">'.__('Code', 'linor').'</a>'
		.'<textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>',
		'title_reply' => '',
		'title_reply_to' => '',
		'comment_notes_before' => '',
		'comment_notes_after' => '',
		'label_submit' => __('Post Comment (Ctrl+Enter)', 'linor')
	);

	if (is_user_logged_in()){
		global $current_user;
		get_currentuserinfo();
		$args['logged_in_as'] = '<p class="logged-in-as">'
			.get_avatar($current_user->user_email, 40)
			.'<strong>'.$user_identity.'</strong>'
			.'<a href="'.admin_url('profile.php').'">'.__('Profile', 'linor').'</a>'
			.'<a href="'.wp_logout_url(get_permalink()).'">'.__('Log out', 'linor').'</a>'
			.'</p>';
	}

	comment_form($args); ?>
</section>