<?php
// Get options
$options = get_option('linor_options');

// Content width
$content_width = 720;

// Sidebar
function linor_widgets_init(){
	register_sidebar(array(
		'name' => __('Sidebar (Home)', 'linor' ),
		'id' => 'sidebar-home',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="title">',
		'after_title' => '</h2>',
	));
	register_sidebar(array(
		'name' => __('Sidebar (Post)', 'linor' ),
		'id' => 'sidebar-post',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="title">',
		'after_title' => '</h2>',
	));
}
add_action('widgets_init', 'linor_widgets_init');

// Navigation
register_nav_menus(array(
	'primary' => __( 'Menu (Primary)', 'linor' ),
	'footer' => __( 'Menu (Footer)', 'linor' ),
));

// Custom background
add_custom_background();

// Custom header
add_custom_image_header('linor_banner_style', 'linor_banner_admin');
define('HEADER_IMAGE_WIDTH', 1000);
define('HEADER_IMAGE_HEIGHT', 300);
define('HEADER_TEXTCOLOR', '555');
define('NO_HEADER_TEXT', true );
function linor_banner_style(){ ?>
	<style type='text/css'>
		header .banner{background: url(<?php header_image(); ?>) #ccc;}
	</style>
<?php }
function linor_banner_admin(){ ?>
	<style type='text/css'>
		#headimg{width: <?php echo HEADER_IMAGE_WIDTH; ?>px;height: <?php echo HEADER_IMAGE_HEIGHT; ?>px;}
	</style>
<?php }

// Add default posts and comments RSS feed links to head
add_theme_support('automatic-feed-links');

// Thumbnails support
add_theme_support('post-thumbnails');

// Custom editor style
add_editor_style('style-editor.css');

// l10n
load_textdomain('linor', dirname(__FILE__).'/lang/' . get_locale() . '.mo');

// Register scripts
wp_register_script('linor-comments', get_bloginfo('template_directory').'/js/comments.js', array('jquery'), '1.0', true);
wp_register_script('linor-fancybox', get_bloginfo('template_directory').'/js/jquery.fancybox.pack.js', array('jquery'), '2.0.5', true);
wp_register_script('linor-main', get_bloginfo('template_directory').'/js/linor.js', array('jquery'), '1.0', true);

// Pagination
function linor_pagenavi(){
	global $wp_query,$wp_rewrite;
	$wp_query->query_vars['paged']>1 ? $current=$wp_query->query_vars['paged'] : $current=1;
	$pagination = array(
		'base' => @add_query_arg('paged','%#%'),
		'format' => '',
		'total' => $wp_query->max_num_pages,
		'mid_size' => 4,
		'type' => 'plain',
		'current' => $current ,
		'prev_text' => __('Prev', 'linor'),
		'next_text' => __('Next', 'linor')
	);
	echo '<nav class="wp-pagenavi">'.paginate_links($pagination).'</nav>';
}

// Comments
function linor_comments($comment, $args, $depth){
	$GLOBALS['comment'] = $comment;
	switch ($comment->comment_type) : // detect comment type
		case 'pingback':
		case 'trackback':
		// if comment is pingback or trackback
	?>
	<li class="pingback">
		<p><strong><?php _e('Pingback', 'linor'); ?></strong><?php comment_author_link(); ?><?php edit_comment_link(__('Edit', 'linor')); ?></p>
	</li>
	<?php
			break;
		default: 
		// if comment is something else
	?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<article class="comment">
			<div class="entry"><?php comment_text(); ?></div>
			<footer>
				<?php echo get_avatar($comment, 40); // avatar ?>
				<div class="alignleft">
					<?php if (get_comment_author_url()) : // author ?>
						<a id="commentauthor-<?php comment_ID() ?>" href="<?php comment_author_url() ?>" rel="external nofollow" class="author"><?php comment_author(); ?></a>
					<?php else : ?>
						<span id="commentauthor-<?php comment_ID() ?>" class="author"><?php comment_author(); ?></span>
					<?php endif; // end author ?>
					<time datetime="<?php comment_time('c') ?>"><?php echo get_comment_date().' '.get_comment_time(); ?></time>
				</div>
				<div class="functions alignright">
					<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __('Reply', 'linor'), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					<?php if (comments_open()) : ?>
						<a href="javascript:void(0);" class="comment-quote-link" title="<?php _e('Quote','linor') ?>"><?php _e('Quote','linor') ?></a>
					<?php endif; ?>
					<?php edit_comment_link(__('Edit', 'linor')); ?>
				</div>
			</footer>
		</article>
	<?php
			break;
	endswitch; // end detect comment type
}
?>