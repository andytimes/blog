<?php if (have_posts()): while (have_posts()): the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="meta">
			<a class="date" href="<?php the_permalink(); ?>"><?php the_date(); ?></a> | 
			<?php comments_popup_link(__('Comment','linor'),__('1 comment','linor'),__('% comments','linor')); ?>
		</div>
		<h1 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
		<div class="entry">
			<?php the_content(); ?>
		</div>
	</article>
	<?php endwhile; ?>
<?php else: get_template_part('search','failed'); endif; ?>
<?php if( $wp_query->max_num_pages > 1 ) {
	linor_pagenavi();
} ?>