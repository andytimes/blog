<div class="widget">
	<?php get_search_form(); ?>
</div>
<div class="widget">
	<h2 class="title"><?php _e( 'Archives', 'linor' ); ?></h2>
	<ul><?php wp_get_archives( 'type=monthly' ); ?></ul>
</div>
<div class="widget">
	<h2 class="title"><?php _e('Categories', 'linor'); ?></h2>
	<ul><?php wp_list_categories('depth=1&title_li='); ?></ul>
</div>
<div class="widget">
	<h2 class="title"><?php _e('Tag Cloud', 'linor'); ?></h2>
	<?php wp_tag_cloud(); ?>
</div>
<div class="widget">
	<h2 class="title"><?php _e( 'Meta', 'linor' ); ?></h2>
	<ul><?php wp_register(); ?><li><?php wp_loginout(); ?></li><?php wp_meta(); ?></ul>
</div>