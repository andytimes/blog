(function() {
  var $;

  $ = jQuery;

  $('.entry').each(function(i) {
    return $(this).find('img').each(function() {
      if ($(this).parent().prop('tagName') === 'a') {
        return $(this).parent().addClass('fancybox').attr('rel', 'gallery' + i);
      } else {
        return $(this).wrap("<a href='" + ($(this).attr('src')) + "' class='fancybox' rel='gallery" + i + "' />");
      }
    });
  });

  $('.fancybox').fancybox();

}).call(this);
